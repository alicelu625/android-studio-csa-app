package com.example.alice.csa_app;

public class ListData {
    public String title;
    public String description;
}
